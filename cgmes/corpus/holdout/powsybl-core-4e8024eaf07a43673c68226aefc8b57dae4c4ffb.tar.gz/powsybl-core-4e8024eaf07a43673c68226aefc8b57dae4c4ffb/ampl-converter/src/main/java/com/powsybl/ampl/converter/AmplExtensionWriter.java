/**
 * Copyright (c) 2018, RTE (http://www.rte-france.com)
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/.
 * SPDX-License-Identifier: MPL-2.0
 */
package com.powsybl.ampl.converter;

import com.powsybl.commons.datasource.DataSource;
import com.powsybl.commons.util.StringToIntMapper;
import com.powsybl.iidm.network.Network;

import java.io.IOException;
import java.util.List;

/**
*
* @author Ferrari Giovanni {@literal <giovanni.ferrari@techrain.eu>}
*/
public interface AmplExtensionWriter {

    String getName();

    void write(List<AmplExtension> extensions, Network network, int variantIndex, StringToIntMapper<AmplSubset> mapper,
            DataSource dataSource, boolean append, AmplExportConfig config) throws IOException;
}
