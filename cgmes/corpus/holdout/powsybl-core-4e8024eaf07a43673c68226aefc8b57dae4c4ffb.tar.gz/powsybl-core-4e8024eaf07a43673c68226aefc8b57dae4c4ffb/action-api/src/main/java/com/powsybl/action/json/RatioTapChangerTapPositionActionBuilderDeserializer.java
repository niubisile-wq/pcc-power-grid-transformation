/**
 * Copyright (c) 2023, RTE (http://www.rte-france.com)
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/.
 * SPDX-License-Identifier: MPL-2.0
 */
package com.powsybl.action.json;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.powsybl.action.RatioTapChangerTapPositionAction;
import com.powsybl.action.RatioTapChangerTapPositionActionBuilder;
import com.powsybl.commons.json.JsonUtil;

import java.io.IOException;

/**
 * @author Etienne Lesot {@literal <etienne.lesot at rte-france.com>}
 */
public class RatioTapChangerTapPositionActionBuilderDeserializer extends AbstractTapChangerTapPositionActionBuilderDeserializer<RatioTapChangerTapPositionActionBuilder> {

    public RatioTapChangerTapPositionActionBuilderDeserializer() {
        super(RatioTapChangerTapPositionActionBuilder.class);
    }

    @Override
    public RatioTapChangerTapPositionActionBuilder deserialize(JsonParser jsonParser, DeserializationContext deserializationContext) throws IOException {
        RatioTapChangerTapPositionActionBuilder builder = new RatioTapChangerTapPositionActionBuilder();
        String version = (String) deserializationContext.getAttribute(ActionListDeserializer.VERSION);
        JsonUtil.parsePolymorphicObject(jsonParser, name -> {
            boolean found = deserializeCommonAttributes(jsonParser, builder, name, version);
            if (found) {
                return true;
            }
            if (name.equals("type")) {
                String type = jsonParser.nextTextValue();
                if (!RatioTapChangerTapPositionAction.NAME.equals(type)) {
                    throw JsonMappingException.from(jsonParser, "Expected type :" + RatioTapChangerTapPositionAction.NAME + " got : " + type);
                }
                return true;
            }
            return false;
        });
        checkFields(builder, jsonParser);
        return builder;
    }
}
