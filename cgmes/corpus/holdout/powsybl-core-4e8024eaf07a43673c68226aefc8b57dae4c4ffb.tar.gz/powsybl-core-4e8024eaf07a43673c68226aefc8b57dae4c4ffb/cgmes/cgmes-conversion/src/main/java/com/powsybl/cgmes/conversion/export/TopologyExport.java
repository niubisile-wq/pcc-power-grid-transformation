/**
 * Copyright (c) 2021, RTE (http://www.rte-france.com)
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/.
 * SPDX-License-Identifier: MPL-2.0
 */
package com.powsybl.cgmes.conversion.export;

import com.powsybl.cgmes.conversion.CgmesExport;
import com.powsybl.cgmes.model.CgmesMetadataModel;
import com.powsybl.cgmes.model.CgmesNames;
import com.powsybl.cgmes.model.CgmesSubset;
import com.powsybl.commons.PowsyblException;
import com.powsybl.commons.exceptions.UncheckedXmlStreamException;
import com.powsybl.iidm.network.*;
import com.powsybl.math.graph.TraverseResult;
import com.powsybl.triplestore.api.PropertyBags;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;
import java.util.*;
import java.util.stream.Collectors;

import static com.powsybl.cgmes.conversion.Conversion.*;
import static com.powsybl.cgmes.conversion.naming.CgmesObjectReference.Part.*;
import static com.powsybl.cgmes.conversion.naming.CgmesObjectReference.ref;
import static com.powsybl.cgmes.conversion.naming.CgmesObjectReference.refTyped;

/**
 * @author Marcos de Miguel {@literal <demiguelm at aia.es>}
 */
public final class TopologyExport {

    private static final Logger LOG = LoggerFactory.getLogger(TopologyExport.class);
    private static final String TOPOLOGICAL_NODE_CONNECTIVITY_NODE_CONTAINER = "TopologicalNode.ConnectivityNodeContainer";
    private static final String TOPOLOGICAL_NODE_BASE_VOLTAGE = "TopologicalNode.BaseVoltage";

    public static void write(Network network, XMLStreamWriter writer) {
        write(network, writer, new CgmesExportContext(network).setExportEquipment(false));
    }

    public static void write(Network network, XMLStreamWriter writer, CgmesExportContext context) {
        CgmesMetadataModel model = CgmesExport.initializeModelForExport(
                network, CgmesSubset.TOPOLOGY, context, true, false);
        write(network, writer, context, model);
    }

    public static void write(Network network, XMLStreamWriter writer, CgmesExportContext context, CgmesMetadataModel model) {
        try {
            String cimNamespace = context.getCim().getNamespace();
            CgmesExportUtil.writeRdfRoot(cimNamespace, context.getCim().getEuPrefix(), context.getCim().getEuNamespace(), writer);

            if (context.getCimVersion() >= 16) {
                CgmesExportUtil.writeModelDescription(network, CgmesSubset.TOPOLOGY, writer, model, context);
            }

            writeTopologicalNodes(network, cimNamespace, writer, context);
            writeTerminals(network, cimNamespace, writer, context);
            writer.writeEndDocument();
        } catch (XMLStreamException e) {
            throw new UncheckedXmlStreamException(e);
        }
    }

    private static void writeTerminals(Network network, String cimNamespace, XMLStreamWriter writer, CgmesExportContext context) throws XMLStreamException {
        writeConnectableTerminals(network, cimNamespace, writer, context);
        writeBoundaryTerminals(network, cimNamespace, writer, context);
        writeSwitchesTerminals(network, cimNamespace, writer, context);
        writeDcTerminals(network, cimNamespace, writer, context);
        // Fictitious injections as NonConformLoad in Bus/Breaker topology: link terminals to TopologicalNode (bus)
        writeFictitiousInjectionTerminals(network, cimNamespace, writer, context);
        // Only if it is an updated export
        if (!context.isExportEquipment()) {
            writeBusbarSectionTerminalsFromBusBranchCgmesModel(network, cimNamespace, writer, context);
        }
    }

    private static void writeFictitiousInjectionTerminals(Network network, String cimNamespace, XMLStreamWriter writer, CgmesExportContext context) throws XMLStreamException {
        for (VoltageLevel vl : network.getVoltageLevels()) {
            if (vl.getTopologyKind() == TopologyKind.NODE_BREAKER && !context.isBusBranchExport()) {
                writeNodeBreakerFictitiousTerminals(vl, cimNamespace, writer, context);
            } else {
                writeBusBranchFictitiousTerminals(vl, cimNamespace, writer, context);
            }
        }
    }

    private static void writeNodeBreakerFictitiousTerminals(VoltageLevel vl, String cimNamespace, XMLStreamWriter writer, CgmesExportContext context) throws XMLStreamException {
        VoltageLevel.NodeBreakerView nodeBreakerView = vl.getNodeBreakerView();

        for (int node : nodeBreakerView.getNodes()) {
            double p = nodeBreakerView.getFictitiousP0(node);
            double q = nodeBreakerView.getFictitiousQ0(node);

            if (p != 0.0 || q != 0.0) {
                String terminalId = context.getNamingStrategy().getCgmesId(refTyped(vl), FICTITIOUS, TERMINAL, ref(node));
                Bus bus = getBusForBusBreakerViewBus(vl, node);
                String topologicalNodeId = context.getNamingStrategy().getCgmesId(bus);
                writeTerminal(terminalId, topologicalNodeId, cimNamespace, writer, context);
            }
        }
    }

    private static void writeBusBranchFictitiousTerminals(VoltageLevel vl, String cimNamespace, XMLStreamWriter writer, CgmesExportContext context) throws XMLStreamException {
        for (Bus bus : vl.getBusBreakerView().getBuses()) {
            double p = bus.getFictitiousP0();
            double q = bus.getFictitiousQ0();

            if (p != 0.0 || q != 0.0) {
                String terminalId = context.getNamingStrategy().getCgmesId(refTyped(bus), FICTITIOUS, TERMINAL);
                String topologicalNodeId = context.getNamingStrategy().getCgmesId(bus);
                writeTerminal(terminalId, topologicalNodeId, cimNamespace, writer, context);
            }
        }
    }

    private static void writeBusbarSectionTerminalsFromBusBranchCgmesModel(Network network, String cimNamespace, XMLStreamWriter writer, CgmesExportContext context) throws XMLStreamException {
        for (Bus b : network.getBusBreakerView().getBuses()) {
            String topologicalNodeId = context.getNamingStrategy().getCgmesId(b);
            String bbsTerminals = b.getProperty(PROPERTY_BUSBAR_SECTION_TERMINALS, "");
            if (!bbsTerminals.isEmpty()) {
                for (String bbsTerminal : bbsTerminals.split(",")) {
                    writeTerminal(bbsTerminal, topologicalNodeId, cimNamespace, writer, context);
                }
            }
        }
    }

    private static void writeConnectableTerminals(Network network, String cimNamespace, XMLStreamWriter writer, CgmesExportContext context) throws XMLStreamException {
        for (Connectable<?> c : network.getConnectables()) { // TODO write boundary terminals for tie lines from CGMES
            if (context.isExportedEquipment(c)) {
                for (Terminal t : c.getTerminals()) {
                    Bus b = t.getBusBreakerView().getBus();
                    if (b == null) {
                        b = t.getBusBreakerView().getConnectableBus();
                    }
                    String topologicalNodeId = context.getNamingStrategy().getCgmesId(b);
                    writeTerminal(CgmesExportUtil.getTerminalId(t, context), topologicalNodeId, cimNamespace, writer, context);
                }
            }
        }
    }

    private static void writeBoundaryTerminals(Network network, String cimNamespace, XMLStreamWriter writer, CgmesExportContext context) throws XMLStreamException {
        List<String> exported = new ArrayList<>();
        for (BoundaryLine bl : network.getBoundaryLines(BoundaryLineFilter.ALL)) {
            writeBoundaryTerminal(bl, exported, cimNamespace, writer, context);
        }
    }

    private static String getBusCgmesId(VoltageLevel vl, Bus bus, int node, CgmesExportContext context) {
        return bus == null ? findOrCreateTopologicalNode(vl, node, context) : context.getNamingStrategy().getCgmesId(bus);
    }

    private static void writeSwitchesTerminals(Network network, String cimNamespace, XMLStreamWriter writer, CgmesExportContext context) throws XMLStreamException {
        for (Switch sw : network.getSwitches()) {
            if (!context.isExportedEquipment(sw)) {
                continue;
            }
            VoltageLevel vl = sw.getVoltageLevel();

            String tn1;
            String tname1;
            String tn2;
            String tname2;
            Bus bus1;
            Bus bus2;
            if (vl.getTopologyKind().equals(TopologyKind.BUS_BREAKER)) {
                bus1 = vl.getBusBreakerView().getBus1(sw.getId());
                tn1 = context.getNamingStrategy().getCgmesId(bus1);
                tname1 = vl.getBusBreakerView().getBus1(sw.getId()).getNameOrId();
                bus2 = vl.getBusBreakerView().getBus2(sw.getId());
                tn2 = context.getNamingStrategy().getCgmesId(bus2);
                tname2 = vl.getBusBreakerView().getBus2(sw.getId()).getNameOrId();
            } else {
                int node1 = vl.getNodeBreakerView().getNode1(sw.getId());
                bus1 = getBusForBusBreakerViewBus(vl, node1);
                tn1 = getBusCgmesId(vl, bus1, node1, context);
                tname1 = bus1 == null ? tn1 : bus1.getNameOrId();

                int node2 = vl.getNodeBreakerView().getNode2(sw.getId());
                bus2 = getBusForBusBreakerViewBus(vl, node2);
                tn2 = getBusCgmesId(vl, bus2, node2, context);
                tname2 = bus2 == null ? tn2 : bus2.getNameOrId();
            }
            writeTopologicalNode(tn1, tname1, bus1, vl, cimNamespace, writer, context);
            writeTopologicalNode(tn2, tname2, bus2, vl, cimNamespace, writer, context);

            String cgmesTerminal1 = context.getNamingStrategy().getCgmesIdFromAlias(sw, ALIAS_TERMINAL1);
            String cgmesTerminal2 = context.getNamingStrategy().getCgmesIdFromAlias(sw, ALIAS_TERMINAL2);

            writeSwitchTerminal(tn1, cgmesTerminal1, cimNamespace, writer, context);
            writeSwitchTerminal(tn2, cgmesTerminal2, cimNamespace, writer, context);
        }
    }

    private static String findOrCreateTopologicalNode(VoltageLevel vl, int node, CgmesExportContext context) {
        Set<Integer> nodeSet = new HashSet<>();
        nodeSet.add(node);

        VoltageLevel.NodeBreakerView.TopologyTraverser traverser = (node1, sw, node2) -> {
            if (sw != null && (sw.isOpen() || sw.isRetained())) {
                return TraverseResult.TERMINATE_PATH;
            }
            nodeSet.add(node2);
            return TraverseResult.CONTINUE;
        };

        vl.getNodeBreakerView().traverse(node, traverser);

        Optional<Bus> selectedBus = nodeSet.stream().map(n -> getBusForBusBreakerViewBus(vl, n)).filter(Objects::nonNull).findFirst();
        if (selectedBus.isPresent()) {
            return context.getNamingStrategy().getCgmesId(selectedBus.get());
        }

        String disconnectedBusId = nodeSet.stream()
                .sorted()
                .findFirst()
                .map(selectedNode -> vl.getId() + "_" + selectedNode)
                .orElseThrow(() -> new PowsyblException("nodeSet is never empty"));
        if (vl.getNetwork().getIdentifiable(disconnectedBusId) != null) { // can happen, particularly with busbar sections - must be distinct or mRIDs will be identical
            disconnectedBusId += "_TN";
        }
        return context.getNamingStrategy().getCgmesId(disconnectedBusId);
    }

    private static void writeTopologicalNode(String tn, String tname, Bus bus, VoltageLevel voltageLevel,
                                             String cimNamespace, XMLStreamWriter writer, CgmesExportContext context) throws XMLStreamException {
        if (context.containsTopologicalNode(tn)) {
            return;
        }
        context.putTopologicalNode(tn, bus);
        writeTopologicalNode(tn, tname, context.getNamingStrategy().getCgmesId(voltageLevel),
            context.getBaseVoltageIdFromNominalV(voltageLevel.getNominalV()), cimNamespace, writer, context);
    }

    private static void writeSwitchTerminal(String tn, String cgmesTerminal, String cimNamespace,
                XMLStreamWriter writer, CgmesExportContext context) throws XMLStreamException {
        writeTerminal(cgmesTerminal, tn, cimNamespace, writer, context);
    }

    private static Bus getBusForBusBreakerViewBus(VoltageLevel vl, int node) {
        Terminal terminal = vl.getNodeBreakerView().getTerminal(node);
        if (terminal == null) {
            return null;
        }

        return terminal.getBusBreakerView().getBus();
    }

    private static void writeDcTerminals(Network network, String cimNamespace, XMLStreamWriter writer, CgmesExportContext context) throws XMLStreamException {
        for (HvdcLine line : network.getHvdcLines()) {
            writeDcTerminals(line, line.getConverterStation1(), 1, cimNamespace, writer, context);
            writeDcTerminals(line, line.getConverterStation2(), 2, cimNamespace, writer, context);
        }
        for (DcConnectable<?> dcConnectable : network.getDcConnectables()) {
            for (DcTerminal dcTerminal : dcConnectable.getDcTerminals()) {
                String className = dcConnectable instanceof AcDcConverter<?> ? CgmesNames.ACDC_CONVERTER_DC_TERMINAL : CgmesNames.DC_TERMINAL;
                String dcTerminalId = CgmesExportUtil.getDcTerminalId(dcTerminal, context);
                String dcTopologicalNodeId = context.getNamingStrategy().getCgmesId(dcTerminal.getDcNode().getDcBus());
                writeDCBaseTerminal(className, dcTerminalId, dcTopologicalNodeId, cimNamespace, writer, context);
            }
        }
        for (DcSwitch dcSwitch : network.getDcSwitches()) {
            String dcTerminal1Id = context.getNamingStrategy().getCgmesIdFromAlias(dcSwitch, ALIAS_DC_TERMINAL1);
            String dcTopologicalNode1Id = context.getNamingStrategy().getCgmesId(dcSwitch.getDcNode1().getDcBus());
            writeDCBaseTerminal(CgmesNames.DC_TERMINAL, dcTerminal1Id, dcTopologicalNode1Id, cimNamespace, writer, context);
            String dcTerminal2Id = context.getNamingStrategy().getCgmesIdFromAlias(dcSwitch, ALIAS_DC_TERMINAL2);
            String dcTopologicalNode2Id = context.getNamingStrategy().getCgmesId(dcSwitch.getDcNode2().getDcBus());
            writeDCBaseTerminal(CgmesNames.DC_TERMINAL, dcTerminal2Id, dcTopologicalNode2Id, cimNamespace, writer, context);
        }
    }

    private static void writeDcTerminals(HvdcLine line, HvdcConverterStation<?> converter, int side, String cimNamespace,
                                         XMLStreamWriter writer, CgmesExportContext context) throws XMLStreamException {
        Bus bus = converter.getTerminal().getBusBreakerView().getBus();
        if (bus == null) {
            bus = converter.getTerminal().getBusBreakerView().getConnectableBus();
        }
        String aliasType = side == 1 ? ALIAS_DC_TERMINAL1 : ALIAS_DC_TERMINAL2;
        // DCTerminal of the DCLineSegment and positive ACDCConverterDCTerminal of the ACDCConverter.
        String dcTopologicalNode = context.getNamingStrategy().getCgmesId(refTyped(bus), DC_TOPOLOGICAL_NODE);
        String dcNode = context.getNamingStrategy().getCgmesId(refTyped(line), DCNODE, ref(side));
        writeDCNode(dcNode, dcTopologicalNode, cimNamespace, writer, context);
        String dcTerminal = context.getNamingStrategy().getCgmesIdFromAlias(line, aliasType);
        writeDCBaseTerminal(CgmesNames.DC_TERMINAL, dcTerminal, dcTopologicalNode, cimNamespace, writer, context);
        String acdcConverterDcTerminal = context.getNamingStrategy().getCgmesIdFromAlias(converter, ALIAS_DC_TERMINAL1);
        writeDCBaseTerminal(CgmesNames.ACDC_CONVERTER_DC_TERMINAL, acdcConverterDcTerminal, dcTopologicalNode, cimNamespace, writer, context);

        // DCTerminal of the DCGround and middle ACDCConverterDCTerminal of the ACDCConverter.
        String dcTopologicalNodeG = context.getNamingStrategy().getCgmesId(refTyped(bus), DC_TOPOLOGICAL_NODE, ref(side + "G"));
        String dcNodeG = context.getNamingStrategy().getCgmesId(refTyped(line), DCNODE, ref(side + "G"));
        writeDCNode(dcNodeG, dcTopologicalNodeG, cimNamespace, writer, context);
        String dcTerminalG = context.getNamingStrategy().getCgmesId(refTyped(line), DC_TERMINAL, ref(side + "G"));
        writeDCBaseTerminal(CgmesNames.DC_TERMINAL, dcTerminalG, dcTopologicalNodeG, cimNamespace, writer, context);
        String acdcConverterDcTerminalG = context.getNamingStrategy().getCgmesIdFromAlias(converter, ALIAS_DC_TERMINAL2);
        writeDCBaseTerminal(CgmesNames.ACDC_CONVERTER_DC_TERMINAL, acdcConverterDcTerminalG, dcTopologicalNodeG, cimNamespace, writer, context);
    }

    private static void writeDCNode(String dcNode, String dcTopologicalNode, String cimNamespace, XMLStreamWriter writer, CgmesExportContext context) throws XMLStreamException {
        CgmesExportUtil.writeStartAbout("DCNode", dcNode, cimNamespace, writer, context);
        CgmesExportUtil.writeReference("DCNode.DCTopologicalNode", dcTopologicalNode, cimNamespace, writer, context);
        writer.writeEndElement();
    }

    private static void writeDCBaseTerminal(String className, String dcBaseTerminalId, String dcTopologicalNodeId,
                                            String cimNamespace, XMLStreamWriter writer, CgmesExportContext context) throws XMLStreamException {
        CgmesExportUtil.writeStartAbout(className, dcBaseTerminalId, cimNamespace, writer, context);
        CgmesExportUtil.writeReference("DCBaseTerminal.DCTopologicalNode", dcTopologicalNodeId, cimNamespace, writer, context);
        writer.writeEndElement();
    }

    private static void writeBoundaryTerminal(BoundaryLine bl, List<String> exported, String cimNamespace, XMLStreamWriter writer, CgmesExportContext context) throws XMLStreamException {
        String boundaryId = CgmesExportUtil.getBoundaryLineBoundaryTerminalId(bl, context);
        String equivalentInjectionTerminalId = context.getNamingStrategy().getCgmesIdFromProperty(bl, PROPERTY_EQUIVALENT_INJECTION_TERMINAL);
        String topologicalNode = getTopologicalNodeId(bl, context);

        // Topological nodes of boundaries are published by external entities and should be ok,
        // we do not make an additional effort to ensure a valid CGMES id has been assigned
        // If not defined it has already been created above so topological node is never null
        if (boundaryId != null) {
            writeTerminal(boundaryId, topologicalNode, cimNamespace, writer, context);
        }
        // check if the equivalent injection terminal has already been written (if several boundary lines linked to same X-node)
        if (equivalentInjectionTerminalId != null && !exported.contains(equivalentInjectionTerminalId)) {
            writeTerminal(equivalentInjectionTerminalId, topologicalNode, cimNamespace, writer, context);
            exported.add(equivalentInjectionTerminalId);
        }
    }

    private static void writeTerminal(String terminalId, String topologicalNode, String cimNamespace, XMLStreamWriter writer, CgmesExportContext context) throws XMLStreamException {
        CgmesExportUtil.writeStartAbout("Terminal", terminalId, cimNamespace, writer, context);
        CgmesExportUtil.writeReference("Terminal.TopologicalNode", topologicalNode, cimNamespace, writer, context);
        writer.writeEndElement();
    }

    private static void writeTopologicalNodes(Network network, String cimNamespace, XMLStreamWriter writer, CgmesExportContext context) throws XMLStreamException {
        writeBusTopologicalNodes(network, cimNamespace, writer, context);
        writeDcTopologicalNodes(network, cimNamespace, writer, context);
        // We create topological nodes for boundary side of boundary lines that are not mapped to an external boundary node
        writeBoundaryLineTopologicalNodes(network, cimNamespace, writer, context);
    }

    private static void writeBoundaryLineTopologicalNodes(Network network, String cimNamespace, XMLStreamWriter writer, CgmesExportContext context) throws XMLStreamException {
        for (BoundaryLine boundaryLine : network.getBoundaryLines(BoundaryLineFilter.UNPAIRED)) {
            writeBoundaryLineTopologicalNode(Collections.singletonList(boundaryLine), cimNamespace, writer, context);
        }

        Map<String, List<BoundaryLine>> boundaryLinesByPairingKey = network.getBoundaryLineStream(BoundaryLineFilter.PAIRED).collect(Collectors.groupingBy(CgmesExportUtil::getEffectivePairingKey));
        for (Map.Entry<String, List<BoundaryLine>> entry : boundaryLinesByPairingKey.entrySet().stream().sorted(Map.Entry.comparingByKey()).toList()) {
            writeBoundaryLineTopologicalNode(entry.getValue(), cimNamespace, writer, context);
        }
    }

    private static void writeBoundaryLineTopologicalNode(List<BoundaryLine> boundaryLineList, String cimNamespace, XMLStreamWriter writer, CgmesExportContext context) throws XMLStreamException {
        if (boundaryLineList.isEmpty()) {
            return;
        }
        // If the topologicalNodeId recorded in the reference data provider is the one associated
        // with the boundary terminal, we do not need to create the TopologicalNode,
        // as it is already defined in the boundary TP file
        Optional<String> cgmesTopologicalNodeId = findCgmesTopologicalNodeId(boundaryLineList.getFirst().getPairingKey(), context);
        String topologicalNodeId = getTopologicalNodeId(boundaryLineList.getFirst(), context);
        if (cgmesTopologicalNodeId.isPresent() && cgmesTopologicalNodeId.get().equals(topologicalNodeId)) {
            return;
        }
        createNewTopologicalNode(boundaryLineList.getFirst(), topologicalNodeId, cimNamespace, writer, context);
    }

    private static String getTopologicalNodeId(BoundaryLine boundaryLine, CgmesExportContext context) {
        if (!boundaryLine.isPaired()) {
            return context.getNamingStrategy().getCgmesIdFromProperty(boundaryLine, PROPERTY_TOPOLOGICAL_NODE_BOUNDARY);
        }
        Optional<String> topologicalNodeId = findCgmesTopologicalNodeId(boundaryLine.getPairingKey(), context);
        if (topologicalNodeId.isPresent()) {
            return context.getNamingStrategy().getCgmesId(topologicalNodeId.get());
        }
        return boundaryLine.hasProperty(PROPERTY_TOPOLOGICAL_NODE_BOUNDARY)
                ? context.getNamingStrategy().getCgmesIdFromProperty(boundaryLine, PROPERTY_TOPOLOGICAL_NODE_BOUNDARY)
                : context.getNamingStrategy().getCgmesIdFromProperty(boundaryLine.getTieLine().orElseThrow(), PROPERTY_TOPOLOGICAL_NODE_BOUNDARY);
    }

    private static Optional<String> findCgmesTopologicalNodeId(String pairingKey, CgmesExportContext context) {
        ReferenceDataProvider referenceDataProvider = context.getReferenceDataProvider();
        if (pairingKey == null || referenceDataProvider == null) {
            return Optional.empty();
        }
        PropertyBags boundaryNodes = referenceDataProvider.getBoundaryNodes();
        if (boundaryNodes == null) {
            return Optional.empty();
        }
        return boundaryNodes.stream()
                .filter(propertyBag -> pairingKey.equals(propertyBag.getId("name")))
                .map(propertyBag1 -> propertyBag1.getId("TopologicalNode"))
                .filter(Objects::nonNull)
                .findFirst();
    }

    private static void createNewTopologicalNode(BoundaryLine bl, String topologicalNodeId, String cimNamespace, XMLStreamWriter writer, CgmesExportContext context) throws XMLStreamException {

        String baseVoltageId = context.getBaseVoltageIdFromNominalV(bl.getTerminal().getVoltageLevel().getNominalV());
        // If the EQ has also been exported, a fictitious container should have been created
        String containerId = context.getFictitiousContainerFor(bl);
        if (containerId == null) {
            // As a last resort, we create the TN in the same container of the boundary line
            LOG.error("Boundary line {}{} is not connected to a topology node in boundaries files: EQ profile must be exported for consistent results." +
                            " Boundary line {} is considered entirely inside voltage level {}",
                    bl.getId(), bl.getPairingKey() != null ? " linked to X-node " + bl.getPairingKey() : "", bl.getId(), bl.getTerminal().getVoltageLevel().getId());
            containerId = context.getNamingStrategy().getCgmesId(bl.getTerminal().getVoltageLevel());
        }
        writeTopologicalNode(topologicalNodeId, bl.getNameOrId() + "_NODE", containerId, baseVoltageId, cimNamespace, writer, context);
    }

    private static void writeBusTopologicalNodes(Network network, String cimNamespace, XMLStreamWriter writer, CgmesExportContext context) throws XMLStreamException {
        for (Bus b : network.getBusBreakerView().getBuses()) {
            String topologicalNodeId = context.getNamingStrategy().getCgmesId(b);
            writeTopologicalNode(topologicalNodeId, b.getNameOrId(), b, b.getVoltageLevel(), cimNamespace, writer, context);
        }
    }

    private static void writeDcTopologicalNodes(Network network, String cimNamespace, XMLStreamWriter writer, CgmesExportContext context) throws XMLStreamException {
        Set<String> written = new HashSet<>();
        for (HvdcLine line : network.getHvdcLines()) {
            writeDCTopologicalNode(line, 1, line.getConverterStation1(), written, cimNamespace, writer, context);
            writeDCTopologicalNode(line, 2, line.getConverterStation2(), written, cimNamespace, writer, context);
        }
        for (DcBus dcBus : network.getDcBuses()) {
            String dcBusId = context.getNamingStrategy().getCgmesId(dcBus);
            writeDCTopologicalNode(dcBusId, dcBus.getNameOrId(), cimNamespace, writer, context);
        }
    }

    private static void writeDCTopologicalNode(HvdcLine line, int side, HvdcConverterStation<?> converter, Set<String> written,
                                               String cimNamespace, XMLStreamWriter writer, CgmesExportContext context) throws XMLStreamException {
        Bus b = converter.getTerminal().getBusBreakerView().getBus();
        if (b == null) {
            b = converter.getTerminal().getBusBreakerView().getConnectableBus();
        }
        if (!written.contains(b.getId())) {
            String id = context.getNamingStrategy().getCgmesId(refTyped(b), DC_TOPOLOGICAL_NODE);
            String name = line.getNameOrId() + side;
            writeDCTopologicalNode(id, name, cimNamespace, writer, context);

            id = context.getNamingStrategy().getCgmesId(refTyped(b), DC_TOPOLOGICAL_NODE, ref(side + "G"));
            name = line.getNameOrId() + side + "G";
            writeDCTopologicalNode(id, name, cimNamespace, writer, context);

            written.add(b.getId());
        }
    }

    private static void writeDCTopologicalNode(String id, String name, String cimNamespace, XMLStreamWriter writer, CgmesExportContext context) throws XMLStreamException {
        CgmesExportUtil.writeStartIdName("DCTopologicalNode", id, name, cimNamespace, writer, context);
        writer.writeEndElement();
    }

    private static void writeTopologicalNode(String topologicalNode, String topologicalNodeName, String connectivityNodeContainerId,
                                             String baseVoltageId, String cimNamespace, XMLStreamWriter writer, CgmesExportContext context) throws XMLStreamException {
        CgmesExportUtil.writeStartIdName("TopologicalNode", topologicalNode, topologicalNodeName, cimNamespace, writer, context);
        CgmesExportUtil.writeReference(TOPOLOGICAL_NODE_CONNECTIVITY_NODE_CONTAINER, connectivityNodeContainerId, cimNamespace, writer, context);
        CgmesExportUtil.writeReference(TOPOLOGICAL_NODE_BASE_VOLTAGE, baseVoltageId, cimNamespace, writer, context);
        writer.writeEndElement();
    }

    private TopologyExport() {
    }
}
