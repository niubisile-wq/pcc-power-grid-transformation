/**
 * Copyright (c) 2017, RTE (http://www.rte-france.com)
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/.
 * SPDX-License-Identifier: MPL-2.0
 */
package com.powsybl.action.ial.dsl;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * @author Mathieu Bague {@literal <mathieu.bague at rte-france.com>}
 */
class RuleTest {

    @Test
    void test() {
        Condition condition = Mockito.mock(Condition.class);

        Rule rule = new Rule("id", condition, 1, Collections.emptyList());
        assertEquals("id", rule.getId());
        assertSame(condition, rule.getCondition());
        assertEquals(1, rule.getLife());
        assertEquals(0, rule.getActions().size());

        assertNull(rule.getDescription());
        rule.setDescription("description");
        assertEquals("description", rule.getDescription());

        rule = new Rule("id", condition, 1, "a1", "a2");
        assertEquals(2, rule.getActions().size());
    }

    @Test
    void testInvalid() {
        Condition condition = Mockito.mock(Condition.class);

        testInvalid(null, null, -1, null, IllegalArgumentException.class);
        testInvalid("id", null, -1, null, IllegalArgumentException.class);
        testInvalid("id", condition, -1, null, IllegalArgumentException.class);
        testInvalid("id", condition, 0, null, NullPointerException.class);
    }

    private void testInvalid(String id, Condition condition, int life, List<String> actions, Class<? extends Throwable> clazz) {
        assertThrows(clazz, () -> new Rule(id, condition, life, actions));
    }

}
